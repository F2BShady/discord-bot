MIT License

Copyright (c) 2024 Shady
